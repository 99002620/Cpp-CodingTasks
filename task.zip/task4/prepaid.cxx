#include "prepaid.h"
PrepaidCustomer::PrepaidCustomer():Customer(),type(Prepaid){}
PrepaidCustomer::PrepaidCustomer(double Pid,std::string Pname,std::string Pnumber,double Pbalance):Customer(Pid,Pname,Pnumber,Pbalance),type(Prepaid){}

void PrepaidCustomer::makeCall(double amount)
{
  setbalance(-amount);
}
void PrepaidCustomer::credit(double amount)
{
  setbalance(amount);
}

