#include "postpaid.h"
PostpaidCustomer::PostpaidCustomer():Customer(),type(Prepaid){}
PostpaidCustomer::PostpaidCustomer(double Pid,std::string Pname,std::string Pnumber,double Pbalance):Customer(Pid,Pname,Pnumber,Pbalance),type(Prepaid){}

void PostpaidCustomer::makeCall(double amount)
{
  setbalance(amount);
}
void PostpaidCustomer::credit(double amount)
{
  setbalance(-amount);
}

