#ifndef CUSTOMER_H_INCLUDED
#define CUSTOMER_H_INCLUDED
#define CalLRate 1.0
#include <iostream>

enum TypeName
{
Prepaid,
Postpaid
};

class Customer
{
    double id;
    std::string name;
    std::string number;
    double balance;
    public:
        Customer();
        Customer(double,std::string,std::string,double);
        virtual void makeCall(double)=0;
        virtual void credit(double)=0;
       double getBalance();
       void setbalance(double);
        std::string getCustomerName();
        double getCustomerId();
        std::string getCustomerNumber();
};


#endif // CUSTOMER_H_INCLUDED
