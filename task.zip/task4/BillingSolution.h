#ifndef BILLINGSOLUTION_H_INCLUDED
#define BILLINGSOLUTION_H_INCLUDED
#include "prepaid.h"
#include <list>
#include <iterator>

class MobileBilling 
{
std::list <PrepaidCustomer> cust;
public:
    PrepaidCustomer* findCustomerById(double);
    int countAll();
    void removeCustomer(double);
    void addCustomer(double,std::string,std::string,double);
    double findAverageBalance();
    double findMaxBalance();
    int countByMinBalance(double);
    PrepaidCustomer* findCustomerByPhone(std::string);
};


#endif // BILLINGSOLUTION_H_INCLUDED
