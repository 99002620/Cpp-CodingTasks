#ifndef PREPAID_H_INCLUDED
#define PREPAID_H_INCLUDED
#include "customer.h"
class PrepaidCustomer: public Customer
{
    TypeName type;
public:
    PrepaidCustomer();
    PrepaidCustomer(double,std::string,std::string,double);
    void makeCall(double);
    void credit(double);

};



#endif // PREPAID_H_INCLUDED
