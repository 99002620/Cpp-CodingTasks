#ifndef POSTPAID_H_INCLUDED
#define POSTPAID_H_INCLUDED
#include "customer.h"
#define NULL nullptr
class PostpaidCustomer: public Customer
{
    TypeName type;
public:
    PostpaidCustomer();
    PostpaidCustomer(double,std::string,std::string,double);
    void makeCall(double) ;
    void credit(double) ;
};


#endif // POSTPAID_H_INCLUDED
