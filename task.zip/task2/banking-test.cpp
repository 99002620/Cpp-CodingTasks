#include "account.h"
#include "savingacc.h"
#include "creditacc.h"
#include "banking.h"
#include <gtest/gtest.h>
#include<iostream>
namespace {

class bankTest : public ::testing::Test {

protected:
  void SetUp()
  {
    bnk.addAccount("srinath", "9845022245", 6000.0,101,0);
    bnk.addAccount("niranjan", "9995012346", 5000.0,102,1);
    bnk.addAccount("asha", "9848882347", 4000.0,103,0);
    bnk.addAccount("shivu", "9845555348", 3000.0,104,1);
    bnk.addAccount("kavya", "9845012349", 2000.0,105,0);
    bnk.addAccount("pravin", "9845012340", 1000.0,106,1);
  }
  void TearDown() {}
  banking bnk;
};

TEST_F(bankTest, AddCustomerTest) 
{
   EXPECT_EQ(3, bnk.findallsavingsaccounts());
 
}


}



